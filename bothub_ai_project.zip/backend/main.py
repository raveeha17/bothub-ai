from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta
from typing import List
from pydantic import BaseModel

import models, auth
from database import engine, get_db

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Bothub.ai API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Pydantic models for validation
class UserCreate(BaseModel):
    email: str
    password: str
    is_admin: bool = False

class UserResponse(BaseModel):
    id: int
    email: str
    is_admin: bool
    class Config:
        from_attributes = True

class ChatbotCreate(BaseModel):
    name: str
    description: str
    category: str = "free"
    features: str = ""

class UserUpdate(BaseModel):
    email: str
    is_admin: bool
    password: str = None

class ChatbotAdminCreate(BaseModel):
    name: str
    description: str
    category: str = "free"
    features: str = ""
    owner_id: int

class ChatbotUpdate(BaseModel):
    name: str
    description: str
    category: str
    features: str
    status: str

class ChatbotResponse(BaseModel):
    id: int
    name: str
    description: str
    owner_id: int
    status: str
    category: str
    features: str
    class Config:
        from_attributes = True

# Helper to get current user
def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = auth.jwt.decode(token, auth.SECRET_KEY, algorithms=[auth.ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except auth.JWTError:
        raise credentials_exception
    user = db.query(models.User).filter(models.User.email == email).first()
    if user is None:
        raise credentials_exception
    return user

# ---- Routes ----

@app.post("/token")
def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not auth.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": user.email, "is_admin": user.is_admin}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/users", response_model=UserResponse)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(email=user.email, hashed_password=hashed_password, is_admin=user.is_admin)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.get("/users/me", response_model=UserResponse)
def read_users_me(current_user: models.User = Depends(get_current_user)):
    return current_user

# Admin routes
@app.get("/admin/users", response_model=List[UserResponse])
def get_all_users(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    return db.query(models.User).all()

@app.post("/admin/users", response_model=UserResponse)
def admin_create_user(user: UserCreate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = auth.get_password_hash(user.password)
    db_user = models.User(email=user.email, hashed_password=hashed_password, is_admin=user.is_admin)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.put("/admin/users/{user_id}", response_model=UserResponse)
def admin_update_user(user_id: int, user_data: UserUpdate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    email_user = db.query(models.User).filter(models.User.email == user_data.email).first()
    if email_user and email_user.id != user_id:
        raise HTTPException(status_code=400, detail="Email already registered by another user")
        
    db_user.email = user_data.email
    db_user.is_admin = user_data.is_admin
    if user_data.password:
        db_user.hashed_password = auth.get_password_hash(user_data.password)
    db.commit()
    db.refresh(db_user)
    return db_user

@app.delete("/admin/users/{user_id}")
def admin_delete_user(user_id: int, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot delete your own admin account")
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Delete related chatbots and analytics
    db.query(models.Analytics).filter(models.Analytics.chatbot_id.in_(
        db.query(models.Chatbot.id).filter(models.Chatbot.owner_id == user_id)
    )).delete(synchronize_session=False)
    db.query(models.Chatbot).filter(models.Chatbot.owner_id == user_id).delete(synchronize_session=False)
    
    db.delete(db_user)
    db.commit()
    return {"detail": "User and associated data deleted successfully"}

@app.get("/admin/chatbots", response_model=List[ChatbotResponse])
def get_all_chatbots(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    return db.query(models.Chatbot).all()

@app.post("/admin/chatbots", response_model=ChatbotResponse)
def admin_create_chatbot(chatbot: ChatbotAdminCreate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    db_chatbot = models.Chatbot(
        name=chatbot.name,
        description=chatbot.description,
        category=chatbot.category,
        features=chatbot.features,
        owner_id=chatbot.owner_id
    )
    db.add(db_chatbot)
    db.commit()
    db.refresh(db_chatbot)
    
    db_analytics = models.Analytics(chatbot_id=db_chatbot.id)
    db.add(db_analytics)
    db.commit()
    return db_chatbot

@app.put("/admin/chatbots/{bot_id}", response_model=ChatbotResponse)
def admin_update_chatbot(bot_id: int, chatbot_data: ChatbotUpdate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    bot = db.query(models.Chatbot).filter(models.Chatbot.id == bot_id).first()
    if not bot:
        raise HTTPException(status_code=404, detail="Bot not found")
    bot.name = chatbot_data.name
    bot.description = chatbot_data.description
    bot.category = chatbot_data.category
    bot.features = chatbot_data.features
    bot.status = chatbot_data.status
    db.commit()
    db.refresh(bot)
    return bot

@app.delete("/admin/chatbots/{bot_id}")
def delete_chatbot(bot_id: int, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    bot = db.query(models.Chatbot).filter(models.Chatbot.id == bot_id).first()
    if not bot:
        raise HTTPException(status_code=404, detail="Bot not found")
    db.delete(bot)
    db.commit()
    return {"detail": "Bot deleted successfully"}

@app.get("/admin/statistics")
def get_statistics(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    analytics = db.query(models.Analytics).all()
    # Simple aggregation for demo
    total_messages = sum(a.messages_handled for a in analytics)
    total_interactions = sum(a.user_interactions for a in analytics)
    total_profit = sum(a.profit for a in analytics)
    total_loss = sum(a.loss for a in analytics)
    
    return {
        "total_messages": total_messages,
        "total_interactions": total_interactions,
        "total_profit": total_profit,
        "total_loss": total_loss,
        "history": [
            {
                "id": a.id,
                "chatbot_id": a.chatbot_id,
                "profit": a.profit,
                "loss": a.loss,
                "messages": a.messages_handled,
                "date": a.date.isoformat()
            } for a in analytics
        ]
    }

# User Bot Routes
@app.post("/chatbots", response_model=ChatbotResponse)
def create_chatbot(chatbot: ChatbotCreate, current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    db_chatbot = models.Chatbot(**chatbot.model_dump(), owner_id=current_user.id)
    db.add(db_chatbot)
    db.commit()
    db.refresh(db_chatbot)
    # create empty analytics for it
    db_analytics = models.Analytics(chatbot_id=db_chatbot.id)
    db.add(db_analytics)
    db.commit()
    return db_chatbot

@app.get("/chatbots", response_model=List[ChatbotResponse])
def get_my_chatbots(current_user: models.User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(models.Chatbot).filter(models.Chatbot.owner_id == current_user.id).all()
