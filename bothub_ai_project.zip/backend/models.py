from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Float, DateTime
from sqlalchemy.orm import relationship
import datetime
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    chatbots = relationship("Chatbot", back_populates="owner")

class Chatbot(Base):
    __tablename__ = "chatbots"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    description = Column(String)
    owner_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    status = Column(String, default="active") # active, inactive
    category = Column(String, default="free") # free, premium, subscription, code, education
    features = Column(String, default="") # JSON or comma separated string

    owner = relationship("User", back_populates="chatbots")
    analytics = relationship("Analytics", back_populates="chatbot")

class Analytics(Base):
    __tablename__ = "analytics"

    id = Column(Integer, primary_key=True, index=True)
    chatbot_id = Column(Integer, ForeignKey("chatbots.id"))
    messages_handled = Column(Integer, default=0)
    user_interactions = Column(Integer, default=0)
    profit = Column(Float, default=0.0)
    loss = Column(Float, default=0.0)
    date = Column(DateTime, default=datetime.datetime.utcnow)

    chatbot = relationship("Chatbot", back_populates="analytics")
