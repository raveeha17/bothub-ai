from sqlalchemy.orm import Session
from database import engine, SessionLocal, Base
import models
import auth
from datetime import datetime, timedelta
import random

# Create tables
Base.metadata.create_all(bind=engine)

def seed_db():
    db = SessionLocal()
    try:
        # Check if admin exists
        admin = db.query(models.User).filter(models.User.email == "admin@bothub.ai").first()
        if not admin:
            admin = models.User(
                email="admin@bothub.ai",
                hashed_password=auth.get_password_hash("admin123"),
                is_admin=True
            )
            db.add(admin)
            db.commit()
            db.refresh(admin)
            print("Admin user created: admin@bothub.ai / admin123")

        # Create 20 random regular users
        regular_users = []
        for i in range(20):
            user = models.User(
                email=f"user{i}@bothub.ai",
                hashed_password=auth.get_password_hash("password123"),
                is_admin=False
            )
            regular_users.append(user)
        db.add_all(regular_users)
        db.commit()
        for user in regular_users:
            db.refresh(user)

        # Create bots with categories
        bot_types = [
            {"name": "Code Companion", "desc": "Assists with coding tasks", "cat": "code", "features": "Syntax highlighting, Code generation, Debugging"},
            {"name": "EduBot", "desc": "Learning assistant", "cat": "education", "features": "Quiz generation, Explanations, Progress tracking"},
            {"name": "Basic Support", "desc": "Simple FAQ bot", "cat": "free", "features": "Text responses, 24/7 uptime"},
            {"name": "Premium AI", "desc": "Advanced analytics and AI", "cat": "premium", "features": "GPT-4 powered, Custom data sources"},
            {"name": "SubBot", "desc": "Subscription-based service", "cat": "subscription", "features": "Monthly updates, Priority support"}
        ]
        
        bots = []
        for bt in bot_types:
            bot = models.Chatbot(
                name=bt["name"],
                description=bt["desc"],
                owner_id=admin.id,
                category=bt["cat"],
                features=bt["features"]
            )
            bots.append(bot)
        
        # Give some bots to regular users
        for i in range(15):
            bot = models.Chatbot(
                name=f"User Bot {i}",
                description="Custom user bot",
                owner_id=random.choice(regular_users).id,
                category=random.choice(["free", "premium"]),
                features="Custom features"
            )
            bots.append(bot)

        db.add_all(bots)
        db.commit()
        for bot in bots:
            db.refresh(bot)
        print("Created categorized chatbots")

        # Create massive analytics data for the past 30 days
        analytics_data = []
        for i in range(30):
            date = datetime.now() - timedelta(days=29 - i)
            for bot in bots[:5]: # just the main 5 bots for simplicity
                base_messages = random.randint(100, 1000)
                analytics = models.Analytics(
                    chatbot_id=bot.id,
                    messages_handled=base_messages + (i * 20), # trend upwards
                    user_interactions=random.randint(50, 300) + (i * 5),
                    profit=random.uniform(50.0, 300.0) + (i * 10),
                    loss=random.uniform(5.0, 50.0),
                    date=date
                )
                analytics_data.append(analytics)
        
        db.add_all(analytics_data)
        db.commit()
        print("Created massive analytics data")

    finally:
        db.close()

if __name__ == "__main__":
    seed_db()
