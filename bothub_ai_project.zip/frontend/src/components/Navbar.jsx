import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bot, LogIn, LayoutDashboard, LogOut } from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const isAdmin = localStorage.getItem('is_admin') === 'true';

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('is_admin');
    navigate('/');
  };

  return (
    <nav className="navbar glass">
      <div className="container nav-container">
        <Link to="/" className="logo">
          <Bot className="logo-icon" size={28} />
          <span>Bothub.ai</span>
        </Link>
        <div className="nav-links">
          <a href="/#features" className="nav-link">Features</a>
          <a href="/#demo" className="nav-link">Demo</a>
          <a href="/#pricing" className="nav-link">Pricing</a>
          <a href="/#contact" className="nav-link">Contact</a>
          {token ? (
            <>
              <Link to="/create-bot" className="nav-link">Create Bot</Link>
              {isAdmin && <Link to="/admin" className="nav-link">Admin</Link>}
              <button onClick={handleLogout} className="btn-outline logout-btn">
                <LogOut size={16} /> Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="btn-primary login-btn">
              <LogIn size={16} /> Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
