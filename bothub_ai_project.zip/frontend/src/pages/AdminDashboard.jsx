import React, { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import { Users, Bot, BarChart3, TrendingUp, TrendingDown, MessageSquare } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const token = localStorage.getItem('token');
  const isAdmin = localStorage.getItem('is_admin') === 'true';

  useEffect(() => {
    if (!token || !isAdmin) {
      navigate('/login');
    }
  }, [token, isAdmin, navigate]);

  useEffect(() => {
    const interceptor = axios.interceptors.response.use(
      response => response,
      error => {
        if (error.response && error.response.status === 401) {
          localStorage.removeItem('token');
          localStorage.removeItem('is_admin');
          navigate('/login');
        }
        return Promise.reject(error);
      }
    );
    return () => {
      axios.interceptors.response.eject(interceptor);
    };
  }, [navigate]);

  return (
    <div className="admin-layout">
      <aside className="admin-sidebar glass">
        <div className="admin-logo">Admin Panel</div>
        <nav className="admin-nav">
          <Link to="/admin" className={`admin-link ${location.pathname === '/admin' ? 'active' : ''}`}>
            <BarChart3 size={20} /> Statistics
          </Link>
          <Link to="/admin/users" className={`admin-link ${location.pathname === '/admin/users' ? 'active' : ''}`}>
            <Users size={20} /> Users
          </Link>
          <Link to="/admin/chatbots" className={`admin-link ${location.pathname === '/admin/chatbots' ? 'active' : ''}`}>
            <Bot size={20} /> Chatbots
          </Link>
        </nav>
      </aside>
      
      <main className="admin-content">
        <Routes>
          <Route path="/" element={<Statistics />} />
          <Route path="/users" element={<UsersList />} />
          <Route path="/chatbots" element={<ChatbotsList />} />
        </Routes>
      </main>
    </div>
  );
};

const Statistics = () => {
  const [stats, setStats] = useState(null);
  const [chatbots, setChatbots] = useState([]);
  const [selectedBotId, setSelectedBotId] = useState('all');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        const [statsRes, botsRes] = await Promise.all([
          axios.get('http://localhost:8000/admin/statistics', {
            headers: { Authorization: `Bearer ${token}` }
          }),
          axios.get('http://localhost:8000/admin/chatbots', {
            headers: { Authorization: `Bearer ${token}` }
          })
        ]);
        setStats(statsRes.data);
        setChatbots(botsRes.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, []);

  if (!stats) return <div className="loading">Loading statistics...</div>;

  // Map chatbot id to name
  const botMap = {};
  chatbots.forEach(b => {
    botMap[b.id] = b.name;
  });

  // Calculate statistics per chatbot
  const botStats = {};
  stats.history.forEach(h => {
    if (!botStats[h.chatbot_id]) {
      botStats[h.chatbot_id] = {
        name: botMap[h.chatbot_id] || `Bot #${h.chatbot_id}`,
        messages: 0,
        profit: 0,
        loss: 0
      };
    }
    botStats[h.chatbot_id].messages += h.messages || 0;
    botStats[h.chatbot_id].profit += h.profit || 0;
    botStats[h.chatbot_id].loss += h.loss || 0;
  });

  // Filter history data for charts
  const filteredHistory = selectedBotId === 'all' 
    ? stats.history 
    : stats.history.filter(h => h.chatbot_id.toString() === selectedBotId);

  // Group filtered history by date
  const chartDataMap = {};
  filteredHistory.forEach(h => {
    const dateStr = new Date(h.date).toLocaleDateString();
    if (!chartDataMap[dateStr]) {
      chartDataMap[dateStr] = { date: h.date, profit: 0, loss: 0, messages: 0 };
    }
    chartDataMap[dateStr].profit += h.profit;
    chartDataMap[dateStr].loss += h.loss;
    chartDataMap[dateStr].messages += h.messages;
  });
  const chartData = Object.values(chartDataMap).sort((a, b) => new Date(a.date) - new Date(b.date));

  // Totals for display cards
  const displayProfit = selectedBotId === 'all' 
    ? stats.total_profit 
    : Object.values(botStats).find((_, idx) => Object.keys(botStats)[idx] === selectedBotId)?.profit || 0;

  const displayLoss = selectedBotId === 'all' 
    ? stats.total_loss 
    : Object.values(botStats).find((_, idx) => Object.keys(botStats)[idx] === selectedBotId)?.loss || 0;

  const displayMessages = selectedBotId === 'all' 
    ? stats.total_messages 
    : Object.values(botStats).find((_, idx) => Object.keys(botStats)[idx] === selectedBotId)?.messages || 0;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="admin-page">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h2>Platform Analytics</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label style={{ fontSize: '14px', fontWeight: 'bold', color: 'var(--text-secondary)' }}>Filter by Bot:</label>
          <select 
            value={selectedBotId} 
            onChange={e => setSelectedBotId(e.target.value)} 
            style={{ padding: '8px 16px', borderRadius: '8px', border: '1px solid var(--border-color)', background: 'white', outline: 'none' }}
          >
            <option value="all">All Chatbots</option>
            {chatbots.map(b => (
              <option key={b.id} value={b.id.toString()}>{b.name}</option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="stats-grid">
        <div className="card stat-card">
          <div className="stat-icon profit"><TrendingUp size={24} /></div>
          <div>
            <p>Profit</p>
            <h3>${displayProfit.toFixed(2)}</h3>
          </div>
        </div>
        <div className="card stat-card">
          <div className="stat-icon loss"><TrendingDown size={24} /></div>
          <div>
            <p>Loss</p>
            <h3>${displayLoss.toFixed(2)}</h3>
          </div>
        </div>
        <div className="card stat-card">
          <div className="stat-icon messages"><MessageSquare size={24} /></div>
          <div>
            <p>Messages Handled</p>
            <h3>{displayMessages}</h3>
          </div>
        </div>
      </div>

      <div className="charts-container">
        <div className="card chart-card">
          <h3>Profit & Loss Over Time</h3>
          <div className="chart-wrapper">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2ecc71" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#2ecc71" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorLoss" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff6b6b" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#ff6b6b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#A0A0A0" tickFormatter={(tick) => new Date(tick).toLocaleDateString()} />
                <YAxis stroke="#A0A0A0" />
                <Tooltip contentStyle={{ backgroundColor: '#1A1A1A', borderColor: '#333' }} />
                <Area type="monotone" dataKey="profit" stroke="#2ecc71" fillOpacity={1} fill="url(#colorProfit)" />
                <Area type="monotone" dataKey="loss" stroke="#ff6b6b" fillOpacity={1} fill="url(#colorLoss)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="card table-card" style={{ marginTop: '30px' }}>
        <h3>Breakdown by Chatbot</h3>
        <table className="admin-table" style={{ marginTop: '16px' }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Chatbot Name</th>
              <th>Total Messages</th>
              <th>Total Profit</th>
              <th>Total Loss</th>
              <th>Net Profit</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(botStats).map(([id, s]) => (
              <tr key={id}>
                <td>{id}</td>
                <td>{s.name}</td>
                <td>{s.messages}</td>
                <td style={{ color: '#2ecc71', fontWeight: 'bold' }}>${s.profit.toFixed(2)}</td>
                <td style={{ color: '#ff6b6b', fontWeight: 'bold' }}>${s.loss.toFixed(2)}</td>
                <td style={{ color: s.profit - s.loss >= 0 ? '#2ecc71' : '#ff6b6b', fontWeight: 'bold' }}>
                  ${(s.profit - s.loss).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

const UsersList = () => {
  const [users, setUsers] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState('');

  const token = localStorage.getItem('token');

  const fetchUsers = async () => {
    try {
      const res = await axios.get('http://localhost:8000/admin/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleOpenModal = (user = null) => {
    setError('');
    if (user) {
      setEditingUser(user);
      setEmail(user.email);
      setPassword('');
      setIsAdmin(user.is_admin);
    } else {
      setEditingUser(null);
      setEmail('');
      setPassword('');
      setIsAdmin(false);
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editingUser) {
        await axios.put(`http://localhost:8000/admin/users/${editingUser.id}`, {
          email,
          is_admin: isAdmin,
          password: password || undefined
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await axios.post(`http://localhost:8000/admin/users`, {
          email,
          password,
          is_admin: isAdmin
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      setIsModalOpen(false);
      fetchUsers();
    } catch (err) {
      setError(err.response?.data?.detail || 'Error saving user');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user? All their bots and analytics will be permanently removed.')) return;
    try {
      await axios.delete(`http://localhost:8000/admin/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchUsers();
    } catch (err) {
      alert(err.response?.data?.detail || 'Error deleting user');
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="admin-page">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2>Users Management</h2>
        <button className="btn-primary" onClick={() => handleOpenModal()}>Add User</button>
      </div>

      <div className="card table-card">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Email</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id}>
                <td>{u.id}</td>
                <td>{u.email}</td>
                <td>{u.is_admin ? <span className="badge admin-badge">Admin</span> : <span className="badge user-badge">User</span>}</td>
                <td>
                  <button className="btn-outline btn-small" onClick={() => handleOpenModal(u)}>Edit</button>
                  <button className="btn-outline btn-small danger" onClick={() => handleDelete(u.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="admin-modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="admin-modal-content card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '400px', width: '100%' }}>
            <h3>{editingUser ? 'Edit User' : 'Add User'}</h3>
            {error && <div className="error-message" style={{ color: 'red', margin: '10px 0' }}>{error}</div>}
            <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '16px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Email</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Password {editingUser && '(Leave blank to keep current)'}</label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} required={!editingUser} />
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type="checkbox" checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} id="isAdmin" style={{ width: 'auto' }} />
                <label htmlFor="isAdmin">Is Admin</label>
              </div>
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary">Save</button>
                <button type="button" className="btn-outline" onClick={() => setIsModalOpen(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </motion.div>
  );
};

const ChatbotsList = () => {
  const [chatbots, setChatbots] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBot, setEditingBot] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('free');
  const [features, setFeatures] = useState('');
  const [status, setStatus] = useState('active');
  const [ownerId, setOwnerId] = useState('');
  const [error, setError] = useState('');

  const token = localStorage.getItem('token');

  const fetchChatbots = async () => {
    try {
      const res = await axios.get('http://localhost:8000/admin/chatbots', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setChatbots(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchChatbots();
  }, []);

  const handleOpenModal = (bot = null) => {
    setError('');
    if (bot) {
      setEditingBot(bot);
      setName(bot.name);
      setDescription(bot.description);
      setCategory(bot.category);
      setFeatures(bot.features);
      setStatus(bot.status);
      setOwnerId(bot.owner_id.toString());
    } else {
      setEditingBot(null);
      setName('');
      setDescription('');
      setCategory('free');
      setFeatures('');
      setStatus('active');
      setOwnerId('1');
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editingBot) {
        await axios.put(`http://localhost:8000/admin/chatbots/${editingBot.id}`, {
          name,
          description,
          category,
          features,
          status
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } else {
        await axios.post(`http://localhost:8000/admin/chatbots`, {
          name,
          description,
          category,
          features,
          owner_id: parseInt(ownerId)
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
      }
      setIsModalOpen(false);
      fetchChatbots();
    } catch (err) {
      setError(err.response?.data?.detail || 'Error saving chatbot');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this chatbot?')) return;
    try {
      await axios.delete(`http://localhost:8000/admin/chatbots/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchChatbots();
    } catch (err) {
      alert(err.response?.data?.detail || 'Error deleting chatbot');
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="admin-page">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h2>Chatbots Management</h2>
        <button className="btn-primary" onClick={() => handleOpenModal()}>Add Chatbot</button>
      </div>

      <div className="card table-card">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Owner ID</th>
              <th>Category</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {chatbots.map(b => (
              <tr key={b.id}>
                <td>{b.id}</td>
                <td>{b.name}</td>
                <td>{b.owner_id}</td>
                <td><span className="badge" style={{ background: '#f0f4f4', color: 'var(--bg-dark-teal)', padding: '4px 8px', borderRadius: '4px', fontSize: '12px' }}>{b.category}</span></td>
                <td><span className={`badge ${b.status}`}>{b.status}</span></td>
                <td>
                  <button className="btn-outline btn-small" onClick={() => handleOpenModal(b)}>Edit</button>
                  <button className="btn-outline btn-small danger" onClick={() => handleDelete(b.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="admin-modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div className="admin-modal-content card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '450px', width: '100%' }}>
            <h3>{editingBot ? 'Edit Chatbot' : 'Add Chatbot'}</h3>
            {error && <div className="error-message" style={{ color: 'red', margin: '10px 0' }}>{error}</div>}
            <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '16px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Name</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} required />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Description</label>
                <textarea rows="2" value={description} onChange={e => setDescription(e.target.value)} required />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Category</label>
                <select value={category} onChange={e => setCategory(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '8px', background: '#f0f4f4', border: 'none', fontFamily: 'inherit', outline: 'none' }}>
                  <option value="free">Free</option>
                  <option value="premium">Premium</option>
                  <option value="subscription">Subscription</option>
                  <option value="code">Code</option>
                  <option value="education">Education</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Features (comma-separated)</label>
                <input type="text" value={features} onChange={e => setFeatures(e.target.value)} />
              </div>
              {!editingBot && (
                <div>
                  <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Owner User ID</label>
                  <input type="number" value={ownerId} onChange={e => setOwnerId(e.target.value)} required />
                </div>
              )}
              {editingBot && (
                <div>
                  <label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: 'bold' }}>Status</label>
                  <select value={status} onChange={e => setStatus(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '8px', background: '#f0f4f4', border: 'none', fontFamily: 'inherit', outline: 'none' }}>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              )}
              <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
                <button type="submit" className="btn-primary">Save</button>
                <button type="button" className="btn-outline" onClick={() => setIsModalOpen(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default AdminDashboard;
