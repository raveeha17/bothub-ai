import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Bot, FileText } from 'lucide-react';
import './CreateBot.css';

const CreateBot = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    try {
      await axios.post('http://localhost:8000/chatbots', 
        { name, description },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setStatus('Bot created successfully! It is now active.');
      setName('');
      setDescription('');
    } catch (err) {
      setStatus('Failed to create bot. Please try again.');
    }
  };

  return (
    <div className="create-bot-page container">
      <motion.div 
        className="create-header"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1>Create a New Bot</h1>
        <p>Configure your AI assistant and deploy it instantly.</p>
      </motion.div>

      <motion.div 
        className="card create-card glass"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        {status && <div className={`status-message ${status.includes('success') ? 'success' : 'error'}`}>{status}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Bot Name</label>
            <div className="input-with-icon">
              <Bot size={18} />
              <input 
                type="text" 
                placeholder="e.g. Sales Assistant" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                required 
              />
            </div>
          </div>

          <div className="form-group">
            <label>Instructions / Description</label>
            <div className="input-with-icon align-top">
              <FileText size={18} />
              <textarea 
                rows="4"
                placeholder="Describe what your bot should do..." 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required 
              ></textarea>
            </div>
          </div>

          <button type="submit" className="btn-primary w-100">
            Deploy Bot
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export default CreateBot;
