import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Image, Cpu, Mic, MessageSquare, Star } from 'lucide-react';
import './Landing.css';

const Landing = () => {
  const [activeCategory, setActiveCategory] = useState('free');
  const [bots, setBots] = useState([]);
  const [demoBot, setDemoBot] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    // Fetch bots to show in the live demo section based on category
    // For demo purposes, we fetch all from the admin endpoint if we can, or just mock them
    // Since this is a public page and our endpoints require auth, we will use mock data that mimics our DB structure for the public landing page.
    const mockBots = [
      { id: 1, name: "Basic Support", description: "Simple FAQ bot", category: "free", features: "Text responses, 24/7 uptime" },
      { id: 2, name: "Premium AI", description: "Advanced analytics and AI", category: "premium", features: "GPT-4 powered, Custom data sources" },
      { id: 3, name: "SubBot", description: "Subscription-based service", category: "subscription", features: "Monthly updates, Priority support" },
      { id: 4, name: "Code Companion", description: "Assists with coding tasks", category: "code", features: "Syntax highlighting, Code generation, Debugging" },
      { id: 5, name: "EduBot", description: "Learning assistant", category: "education", features: "Quiz generation, Explanations" }
    ];
    setBots(mockBots.filter(b => b.category === activeCategory));
  }, [activeCategory]);

  const handleSendDemoMessage = (e) => {
    e.preventDefault();
    if (!inputVal.trim() || isTyping) return;

    const userMsg = { sender: 'user', text: inputVal };
    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    setTimeout(() => {
      let replyText = "Hello! I am Bothub.ai's assistant. How can I help you today?";
      if (demoBot) {
        const category = demoBot.category.toLowerCase();
        if (category === 'code') {
          replyText = `Here is a custom Python script for your request:\n\`\`\`python\ndef bothub_assistant():\n    print("Welcome to ${demoBot.name}!")\n    return True\n\`\`\``;
        } else if (category === 'education') {
          replyText = `Here is a quick question for you to test your knowledge:\n\n**What is the capital of France?**\n1. London\n2. Paris\n3. Berlin\n\n(Type the correct option to continue!)`;
        } else if (category === 'premium') {
          replyText = `I have completed an advanced AI analysis of your request. According to our machine learning model, the predicted conversion rate has increased by 18.5% this quarter. Let me know if you would like me to compile a full report.`;
        } else if (category === 'subscription') {
          replyText = `Thank you for choosing our premium subscription services. Your monthly updates are active, and our priority support channels are open 24/7. How can I assist you with your subscription today?`;
        } else {
          replyText = `Thanks for testing our free support chatbot! Our basic plan is online and handles user FAQs instantly with 24/7 uptime. Upgrading to premium gives you access to custom data training!`;
        }
      }
      setMessages(prev => [...prev, { sender: 'bot', text: replyText }]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <div className="landing-page">
      {/* HERO SECTION */}
      <section className="hero">
        <div className="container hero-container">
          <motion.div 
            className="hero-content"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="hero-title">Welcome to Easy Chat Fast Solutions with Our Chatbot!</h1>
            <p className="hero-subtitle">
              The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. 
              Deploy powerful AI easily.
            </p>
            <div className="hero-actions">
              <Link to="/create-bot" className="btn-primary">Get Started</Link>
              <a href="#pricing" className="btn-white">Get Premium</a>
            </div>
          </motion.div>
          
          <motion.div 
            className="hero-image-wrapper"
            animate={{ y: [0, -20, 0] }}
            transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
          >
            <img src="/robot.png" alt="3D Teal Robot" className="robot-image" />
          </motion.div>
        </div>
      </section>

      {/* WHY CHOOSE US & FEATURES GRID */}
      <section className="features-section container" id="features">
        <div className="features-container">
          <motion.div 
            className="features-grid"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={{
              visible: { transition: { staggerChildren: 0.1 } },
              hidden: {}
            }}
          >
            <motion.div className="feature-box light" variants={{hidden: {opacity: 0}, visible: {opacity: 1}}}>
              <Image size={32} />
              <h4>Image Processing</h4>
            </motion.div>
            <motion.div className="feature-box" variants={{hidden: {opacity: 0}, visible: {opacity: 1}}}>
              <Cpu size={32} />
              <h4>Machine Learning</h4>
            </motion.div>
            <motion.div className="feature-box" variants={{hidden: {opacity: 0}, visible: {opacity: 1}}}>
              <Mic size={32} />
              <h4>Voice Recognition</h4>
            </motion.div>
            <motion.div className="feature-box" variants={{hidden: {opacity: 0}, visible: {opacity: 1}}}>
              <MessageSquare size={32} />
              <h4>Chatbot Generate</h4>
            </motion.div>
          </motion.div>
          
          <div className="features-text">
            <h2>Simplify Life,<br/>With Smarter Answers</h2>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>
              Why choose us? The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. 
              We provide the fastest, most reliable AI chatbot architecture in the industry.
            </p>
            <a href="#pricing" className="btn-primary">Try to Get Premium</a>
          </div>
        </div>
      </section>

      {/* BOT CATEGORIES & LIVE DEMO */}
      <section className="demo-section container" id="demo">
        <h2 className="section-title">Explore Bot Categories & Live Demos</h2>
        <div className="demo-tabs">
          {['free', 'premium', 'subscription', 'code', 'education'].map(cat => (
            <button 
              key={cat} 
              className={`tab-btn ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>
        <div className="bot-list">
          {bots.map(bot => (
            <motion.div key={bot.id} className="card bot-card" initial={{opacity:0}} animate={{opacity:1}} style={{ display: 'flex', flexDirection: 'column' }}>
              <h4>{bot.name}</h4>
              <p style={{color: 'var(--text-secondary)', marginBottom: '16px'}}>{bot.description}</p>
              <div style={{fontSize: '12px', background: '#f0f4f4', padding: '10px', borderRadius: '8px', marginBottom: '20px'}}>
                <strong>Features:</strong> {bot.features}
              </div>
              <button 
                className="btn-outline" 
                style={{width: '100%', marginTop: 'auto'}}
                onClick={() => {
                  setDemoBot(bot);
                  setMessages([
                    { sender: 'bot', text: `Hi! I am ${bot.name}, your ${bot.category} assistant. Let's start the live demo! Ask me anything.` }
                  ]);
                }}
              >
                Launch Live Demo
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* PRICING PLANS */}
      <section className="pricing-section" id="pricing">
        <div className="container">
          <h2 className="section-title">Plans Designed Around You</h2>
          <div className="pricing-grid">
            <div className="price-card">
              <h3>Starter Plan</h3>
              <div className="amount">$100<span style={{fontSize:'16px', fontWeight:'normal'}}>/Monthly</span></div>
              <ul>
                <li>✓ Suitable for personal users</li>
                <li>✓ Enhanced chat capabilities</li>
                <li>✓ Limited conversation history</li>
                <li>✓ Limited to business hours</li>
              </ul>
              <button className="btn-white">Select Plan</button>
            </div>
            <div className="price-card featured">
              <h3>Pro Plan</h3>
              <div className="amount">$150<span style={{fontSize:'16px', fontWeight:'normal'}}>/Monthly</span></div>
              <ul>
                <li>✓ Suitable for power users</li>
                <li>✓ Advanced chat capabilities</li>
                <li>✓ Unlimited conversation history</li>
                <li>✓ 24/7 Priority Support</li>
              </ul>
              <button className="btn-primary" style={{background: 'var(--bg-dark-teal)', color: 'white'}}>Select Plan</button>
            </div>
            <div className="price-card">
              <h3>Business Plan</h3>
              <div className="amount">$130<span style={{fontSize:'16px', fontWeight:'normal'}}>/Monthly</span></div>
              <ul>
                <li>✓ Suitable for small teams</li>
                <li>✓ Enhanced chat capabilities</li>
                <li>✓ Extended conversation history</li>
                <li>✓ Limited to business hours</li>
              </ul>
              <button className="btn-white">Select Plan</button>
            </div>
          </div>
        </div>
      </section>

      {/* REVIEWS SECTION */}
      <section className="reviews-section">
        <h2 className="section-title" style={{color:'white', paddingTop:'40px'}}>What Our Users Say</h2>
        <div className="reviews-grid">
          {[1,2,3].map(i => (
            <div className="review-card" key={i}>
              <div className="reviewer-info">
                <img src={`https://i.pravatar.cc/150?img=${i+10}`} alt="User" />
                <div>
                  <h4 style={{margin:0}}>Jerome Bell</h4>
                  <div style={{color:'#f1c40f'}}><Star size={14} fill="currentColor"/> <Star size={14} fill="currentColor"/> <Star size={14} fill="currentColor"/> <Star size={14} fill="currentColor"/> <Star size={14} fill="currentColor"/></div>
                </div>
              </div>
              <p style={{fontSize:'14px', opacity:0.9}}>
                "This chatbot platform changed the way we handle customer support. The UI Legends aesthetic makes it feel incredibly premium."
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACT US & MAP */}
      <section className="contact-section" id="contact">
        <div className="container contact-container">
          <div className="contact-form">
            <h2>Contact Us</h2>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="form-group">
                <input type="text" placeholder="Your Name" />
              </div>
              <div className="form-group">
                <input type="email" placeholder="Your Email" />
              </div>
              <div className="form-group">
                <textarea rows="4" placeholder="Your Message"></textarea>
              </div>
              <button className="btn-primary">Send Message</button>
            </form>
          </div>
          <div className="map-container">
            <img src="/map.png" alt="Our Location" />
          </div>
        </div>
      </section>

      {/* LIVE DEMO MODAL */}
      {demoBot && (
        <div className="demo-modal-overlay" onClick={() => setDemoBot(null)}>
          <motion.div 
            className="demo-modal-content glass"
            onClick={(e) => e.stopPropagation()}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            <div className="demo-modal-header">
              <div>
                <h3 style={{ color: 'var(--bg-dark-teal)' }}>Live Demo: {demoBot.name}</h3>
                <span className="badge category-badge" style={{ background: 'var(--bg-dark-teal)', color: 'white', padding: '4px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold' }}>
                  {demoBot.category.toUpperCase()}
                </span>
              </div>
              <button className="close-btn" style={{ background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: 'var(--text-secondary)' }} onClick={() => setDemoBot(null)}>&times;</button>
            </div>
            
            <div className="demo-chat-body" style={{ maxHeight: '300px', overflowY: 'auto', padding: '16px 0', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {messages.map((msg, i) => (
                <div key={i} className={`chat-bubble-wrapper ${msg.sender}`} style={{ display: 'flex', justifyContent: msg.sender === 'user' ? 'flex-end' : 'flex-start' }}>
                  <div className="chat-bubble" style={{
                    background: msg.sender === 'user' ? 'var(--bg-dark-teal)' : '#f0f4f4',
                    color: msg.sender === 'user' ? 'white' : 'var(--text-primary)',
                    padding: '10px 16px',
                    borderRadius: '16px',
                    maxWidth: '80%',
                    boxShadow: 'var(--shadow-sm)'
                  }}>
                    <pre style={{ fontFamily: 'inherit', whiteSpace: 'pre-wrap', margin: 0 }}>{msg.text}</pre>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="chat-bubble-wrapper bot" style={{ display: 'flex', justifyContent: 'flex-start' }}>
                  <div className="chat-bubble typing" style={{ background: '#f0f4f4', padding: '10px 16px', borderRadius: '16px', display: 'flex', gap: '4px', alignItems: 'center' }}>
                    <div style={{ width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%', animation: 'bounce 1s infinite alternate' }}></div>
                    <div style={{ width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%', animation: 'bounce 1s infinite alternate 0.2s' }}></div>
                    <div style={{ width: '6px', height: '6px', background: 'var(--text-secondary)', borderRadius: '50%', animation: 'bounce 1s infinite alternate 0.4s' }}></div>
                  </div>
                </div>
              )}
            </div>

            <form className="demo-chat-footer" onSubmit={handleSendDemoMessage} style={{ display: 'flex', gap: '10px', marginTop: '16px' }}>
              <input 
                type="text" 
                placeholder="Type a message to the bot..." 
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                disabled={isTyping}
                style={{ flex: 1 }}
              />
              <button type="submit" className="btn-primary" disabled={isTyping}>Send</button>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default Landing;
