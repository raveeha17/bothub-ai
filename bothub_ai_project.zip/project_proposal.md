# Project Proposal: Bothub.ai - Next-Gen AI Chatbot Platform

## Executive Summary
**Bothub.ai** is an interactive, premium-tier AI Chatbot platform designed to simplify user communication through high-performance chatbot integration. This proposal outlines the comprehensive architecture, design assets, administrative control, and telemetry tracking dashboards built on a modern **Python (FastAPI) + React** stack.

---

## 1. Product Overview & Key Features

### 1.1 UI Legends Premium Landing Page
- A high-fidelity frontend layout utilizing smooth scrolling, premium typography (Inter), and custom SVG icons (Lucide).
- Muted premium teal and mint color palettes (avoiding standard harsh primary colors and neon lights).
- Floating 3D robot graphics and card micro-animations (Framer Motion).

### 1.2 Interactive Live Demo Modals
- Live chat modal overlays on each chatbot card on the landing page.
- Context-aware chatbot simulators that process user prompts and respond based on their tier:
  - **Code Companion**: Generates syntax-highlighted code.
  - **EduBot**: Initiates interactive trivia checks.
  - **Premium & Subscription AI**: Displays telemetry reports and advanced metrics.
  - **Free Support**: Provides instant FAQ troubleshooting responses.

### 1.3 Complete Administrative CRUD Control
- **Secure Authentication**: JWT-based session security with token expiry tracking.
- **User Management**: Admin interface to view, register, edit details, toggle administrator privileges, and delete users.
- **Chatbot Management**: Custom form dialogs to provision new chatbots, alter descriptions, switch status (Active/Inactive), and assign categories.

### 1.4 Business Intelligence & Analytics Dashboard
- Aggregated indicators showing **Total Profit, Total Loss, and Messages Handled**.
- **Interactive Select Filters**: Toggle views between aggregated system analytics or drill down into statistics for individual chatbots.
- **Telemetry Charts**: Interactive Recharts AreaCharts detailing profit/loss streams and message counts over time.
- **Chatbot Performance breakdown**: Dynamic comparison table displaying net yields and conversion indices.

---

## 2. Technology Stack & System Design

```mermaid
graph TD
    subgraph Client [React Frontend App]
        Landing[Landing Page & Live Chat Demo]
        Dashboard[Admin Panel CRUD & Recharts]
        State[Axios Auth Interceptors & State]
    end
    
    subgraph Server [FastAPI Backend Server]
        API[Auth & Admin API Endpoints]
        JWT[OAuth2 & JWT Validation]
    end
    
    subgraph Database [SQLite Storage]
        DB[(bothub.db SQL File)]
    end

    Landing -->|Requests| API
    Dashboard -->|Authorized Admin Requests| API
    State -->|Tokens| JWT
    API -->|ORM queries| DB
```

### 2.1 Backend Architecture
- **Framework**: FastAPI (Asynchronous endpoints, clean Pydantic validations, and automatic Swagger docs).
- **ORM**: SQLAlchemy (Declarative mapping for modular table configurations).
- **Database**: SQLite (Optimized schema including relational maps between Users, Chatbots, and Analytics records).
- **Security**: PyJWT + Passlib (Bcrypt hashing for password salts, validation tokens).

### 2.2 Frontend Architecture
- **Framework**: React 18 powered by Vite.
- **Charts**: Recharts (Responsive Area and Line charts utilizing smooth SVG gradients).
- **Animations**: Framer Motion (State-based transition loops).
- **Styling**: Vanilla CSS variable maps containing custom HSL coordinates for consistent theme enforcement.

---

## 3. Design Aesthetics & Visual Specs
Bothub.ai uses a high-contrast premium theme centered on teal and mint tones:
- **Primary Teal Color**: `#145C5A` (Deep Muted Teal)
- **Mint Accent Color**: `#7bc5c3` (Soft Teal / Mint Green)
- **Background Hue**: `#f8fbfb` (Clean White with Mint undertones)
- **Aesthetic Effects**: Glassmorphism (`backdrop-filter: blur(8px)` overlays, thin semi-transparent borders).

---

## 4. Implementation Timeline

| Phase | Milestone | Deliverable | Status |
|---|---|---|---|
| **Phase 1** | Foundation & API Design | Schema mappings, Database Seed script | **Completed** |
| **Phase 2** | UI Legends Landing Page | Muted teal layout with smooth scrolls | **Completed** |
| **Phase 3** | Interactive Live Demos | Multi-category context-aware chat modals | **Completed** |
| **Phase 4** | Secure Admin Panel | CRUD overlays, automatic auth interceptors | **Completed** |
| **Phase 5** | Telemetry Reporting | Recharts integrations, chatbot breakdowns | **Completed** |
